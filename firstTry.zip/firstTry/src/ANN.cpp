#include <iostream>

#include "headers/ANN.h"

ANN::ANN() {
}

ANN::~ANN() {
}

void ANN::setANNParameters(int inputSize, int outputSize) {
    int i;

    aux.push_back(inputSize);

    for (i = 0; i < layerSize; i++) {
        aux.push_back(layers[i]);
    }

    aux.push_back(outputSize);

    intermediunOut = new vectorF[layerSize + 2];
    matrixArrayTest = new MatrixF[layerSize + 1];

    for (i = 0; i < layerSize + 1; i++) {
        matrixArrayTest[i].createMatrix(aux[i + 1], aux[i], RAND_LIMIT);
    }

    for (i = 0; i < layerSize + 2; i++) {
        intermediunOut[i].createVector(aux[i]);
    }
}

void ANN::reset() {
    for (int i = 0; i < layerSize + 1; i++) {
        matrixArrayTest[i].createMatrix(aux[i+1], aux[i], RAND_LIMIT);
    }
}

void ANN::multiply() {
    int i;
    int j;

    for (i = 1; i < layerSize + 2; i++) {
        intermediunOut[i] = matrixArrayTest[i-1] * intermediunOut[i-1];

        for (j = 0; j < intermediunOut[i].size; j++) {
            intermediunOut[i].vector[j] = tanh(intermediunOut[i][j]);
        }
    }
}

MatrixF *ANN::setMatrix(MatrixF *matrixArray) {
    MatrixF *temp;
    temp = this->matrixArrayTest;
    this->matrixArrayTest = matrixArray;

    return temp;
}

void ANN::copyWheights(MatrixF *matrixArray) {
    for (int i = 0; i < layerSize + 1; i++)
        this->matrixArrayTest[i] = matrixArray[i];
}